import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table with gamification
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").unique(),
  level: integer("level").default(1),
  experiencePoints: integer("experience_points").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Footprint calculations
export const footprintCalculations = pgTable("footprint_calculations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  totalFootprint: real("total_footprint").notNull(),
  transportation: real("transportation").default(0),
  energy: real("energy").default(0),
  food: real("food").default(0),
  consumption: real("consumption").default(0),
  calculationData: jsonb("calculation_data"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Environmental stories
export const stories = pgTable("stories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  country: text("country").notNull(),
  category: text("category").notNull(),
  imageUrl: text("image_url"),
  readTime: integer("read_time").default(5),
  likes: integer("likes").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// User achievements
export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  achievementType: text("achievement_type").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

// Environmental data (from Our World in Data)
export const environmentalData = pgTable("environmental_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  country: text("country").notNull(),
  year: integer("year").notNull(),
  co2Emissions: real("co2_emissions"),
  renewableEnergy: real("renewable_energy"),
  population: integer("population"),
  gdpPerCapita: real("gdp_per_capita"),
});

// Global statistics
export const globalStats = pgTable("global_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  metric: text("metric").notNull(),
  value: real("value").notNull(),
  unit: text("unit"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Newsletter subscriptions
export const newsletterSubscriptions = pgTable("newsletter_subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  isActive: boolean("is_active").default(true),
  subscribedAt: timestamp("subscribed_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
});

export const insertFootprintSchema = createInsertSchema(footprintCalculations).omit({
  id: true,
  createdAt: true,
});

export const insertStorySchema = createInsertSchema(stories).omit({
  id: true,
  likes: true,
  createdAt: true,
});

export const insertNewsletterSchema = createInsertSchema(newsletterSubscriptions).pick({
  email: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertFootprint = z.infer<typeof insertFootprintSchema>;
export type FootprintCalculation = typeof footprintCalculations.$inferSelect;
export type InsertStory = z.infer<typeof insertStorySchema>;
export type Story = typeof stories.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type EnvironmentalData = typeof environmentalData.$inferSelect;
export type GlobalStat = typeof globalStats.$inferSelect;
export type InsertNewsletter = z.infer<typeof insertNewsletterSchema>;
export type NewsletterSubscription = typeof newsletterSubscriptions.$inferSelect;
