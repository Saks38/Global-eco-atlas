interface CarbonTip {
  category: string;
  tip: string;
  impact: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export function getCarbonTips(userChoices: {
  transportation?: string;
  homeSize?: string;
  energySource?: string;
  diet?: string;
  recycling?: string;
}): CarbonTip[] {
  const tips: CarbonTip[] = [];

  // Transportation tips
  if (userChoices.transportation === 'car') {
    tips.push(
      {
        category: 'Transportation',
        tip: 'Consider carpooling, using public transit, or biking for short trips',
        impact: 'Can reduce transport emissions by 45%',
        difficulty: 'Easy'
      },
      {
        category: 'Transportation',
        tip: 'Walk or bike for trips under 2 miles instead of driving',
        impact: 'Saves 2.6 lbs CO2 per mile',
        difficulty: 'Easy'
      },
      {
        category: 'Transportation',
        tip: 'Consider a hybrid or electric vehicle for your next car purchase',
        impact: 'Reduces emissions by 60-80%',
        difficulty: 'Hard'
      }
    );
  } else if (userChoices.transportation === 'public') {
    tips.push({
      category: 'Transportation',
      tip: 'Great choice! Consider biking or walking for even shorter trips',
      impact: 'Additional 20% emission reduction',
      difficulty: 'Easy'
    });
  }

  // Home energy tips
  if (userChoices.homeSize === 'large') {
    tips.push(
      {
        category: 'Home Energy',
        tip: 'Install a programmable thermostat to optimize heating and cooling',
        impact: 'Saves 10-15% on energy bills',
        difficulty: 'Medium'
      },
      {
        category: 'Home Energy',
        tip: 'Upgrade to LED light bulbs throughout your home',
        impact: 'Uses 75% less energy than incandescent',
        difficulty: 'Easy'
      }
    );
  }

  if (userChoices.energySource === 'fossil') {
    tips.push(
      {
        category: 'Energy',
        tip: 'Switch to a renewable energy provider or install solar panels',
        impact: 'Can eliminate home energy emissions',
        difficulty: 'Hard'
      },
      {
        category: 'Energy',
        tip: 'Unplug electronics when not in use to avoid phantom loads',
        impact: 'Saves 5-10% on electricity bills',
        difficulty: 'Easy'
      }
    );
  }

  // Diet tips
  if (userChoices.diet === 'high-meat') {
    tips.push(
      {
        category: 'Diet',
        tip: 'Try "Meatless Monday" - reduce meat consumption one day per week',
        impact: 'Saves 1,900 lbs CO2 annually',
        difficulty: 'Easy'
      },
      {
        category: 'Diet',
        tip: 'Choose locally sourced and seasonal produce when possible',
        impact: 'Reduces food transport emissions by 30%',
        difficulty: 'Medium'
      }
    );
  } else if (userChoices.diet === 'vegetarian') {
    tips.push({
      category: 'Diet',
      tip: 'Excellent! Consider reducing food waste and composting organic matter',
      impact: 'Prevents 30% of food-related emissions',
      difficulty: 'Easy'
    });
  }

  // Recycling tips
  if (userChoices.recycling === 'sometimes') {
    tips.push(
      {
        category: 'Waste',
        tip: 'Set up a home recycling system to make it easier to recycle consistently',
        impact: 'Proper recycling saves 2,000 lbs CO2 annually',
        difficulty: 'Easy'
      },
      {
        category: 'Waste',
        tip: 'Reduce single-use plastics by using reusable bags and water bottles',
        impact: 'Prevents 300 lbs of plastic waste yearly',
        difficulty: 'Easy'
      }
    );
  }

  // Universal tips
  tips.push(
    {
      category: 'Water',
      tip: 'Take shorter showers and fix leaky faucets',
      impact: 'Saves 2,300 lbs CO2 per year',
      difficulty: 'Easy'
    },
    {
      category: 'Consumption',
      tip: 'Buy only what you need and choose quality items that last longer',
      impact: 'Reduces consumption emissions by 25%',
      difficulty: 'Medium'
    }
  );

  return tips.slice(0, 6); // Return top 6 most relevant tips
}