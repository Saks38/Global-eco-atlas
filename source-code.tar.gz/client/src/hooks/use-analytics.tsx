import { useState, useEffect } from 'react';

interface AnalyticsData {
  totalUsers: number;
  activeUsers: number;
  dailyVisitors: number;
  calculationsCompleted: number;
  co2Saved: number;
}

export function useAnalytics() {
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    totalUsers: 0,
    activeUsers: 0,
    dailyVisitors: 0,
    calculationsCompleted: 0,
    co2Saved: 0
  });

  useEffect(() => {
    // Track real user sessions using localStorage and sessionStorage
    const updateRealAnalytics = () => {
      // Get or initialize user tracking data
      let userData = localStorage.getItem('eco-atlas-users');
      let userCount = userData ? JSON.parse(userData) : { total: 0, sessions: [] };
      
      // Track current session
      const sessionId = sessionStorage.getItem('eco-session-id') || Math.random().toString(36);
      if (!sessionStorage.getItem('eco-session-id')) {
        sessionStorage.setItem('eco-session-id', sessionId);
        userCount.total += 1;
      }
      
      // Clean old sessions (older than 24 hours)
      const now = Date.now();
      userCount.sessions = userCount.sessions.filter((session: any) => 
        now - session.timestamp < 24 * 60 * 60 * 1000
      );
      
      // Add current session if not already tracked today
      const existingSession = userCount.sessions.find((s: any) => s.id === sessionId);
      if (!existingSession) {
        userCount.sessions.push({ id: sessionId, timestamp: now });
      }
      
      // Get calculations from localStorage
      const calculations = localStorage.getItem('eco-calculations');
      const calcCount = calculations ? JSON.parse(calculations).length || 0 : 0;
      
      // Calculate metrics based on real data
      const totalUsers = Math.max(userCount.total, 1);
      const activeUsers = userCount.sessions.filter((s: any) => 
        now - s.timestamp < 30 * 60 * 1000 // Active in last 30 minutes
      ).length;
      const dailyVisitors = userCount.sessions.length;
      const calculationsCompleted = calcCount;
      const co2Saved = Math.floor(calcCount * 2.3); // Estimated CO2 savings per calculation
      
      // Save updated user data
      localStorage.setItem('eco-atlas-users', JSON.stringify(userCount));
      
      setAnalytics({
        totalUsers,
        activeUsers,
        dailyVisitors,
        calculationsCompleted,
        co2Saved
      });
    };

    updateRealAnalytics();
    const interval = setInterval(updateRealAnalytics, 10000); // Update every 10 seconds

    return () => clearInterval(interval);
  }, []);

  return analytics;
}