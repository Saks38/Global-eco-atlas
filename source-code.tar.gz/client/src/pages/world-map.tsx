import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Search, Filter, Globe, TrendingUp, TrendingDown } from "lucide-react";

const mockCountries = [
  { name: "United States", co2: 15.5, renewable: 21, population: 331900000, region: "North America" },
  { name: "China", co2: 7.4, renewable: 31, population: 1439300000, region: "Asia" },
  { name: "Germany", co2: 8.4, renewable: 46, population: 83240000, region: "Europe" },
  { name: "India", co2: 1.9, renewable: 11, population: 1380000000, region: "Asia" },
  { name: "Japan", co2: 8.7, renewable: 20, population: 125800000, region: "Asia" },
  { name: "Brazil", co2: 2.3, renewable: 83, population: 212600000, region: "South America" },
  { name: "Canada", co2: 18.6, renewable: 68, population: 38000000, region: "North America" },
  { name: "France", co2: 4.6, renewable: 23, population: 67400000, region: "Europe" },
  { name: "United Kingdom", co2: 5.2, renewable: 43, population: 67900000, region: "Europe" },
  { name: "Australia", co2: 15.4, renewable: 28, population: 25700000, region: "Oceania" },
  { name: "Russia", co2: 11.4, renewable: 19, population: 146000000, region: "Europe" },
  { name: "Mexico", co2: 3.7, renewable: 26, population: 128900000, region: "North America" },
  { name: "Indonesia", co2: 2.3, renewable: 12, population: 273500000, region: "Asia" },
  { name: "Nigeria", co2: 0.6, renewable: 6, population: 218500000, region: "Africa" },
  { name: "Pakistan", co2: 0.9, renewable: 4, population: 225200000, region: "Asia" },
  { name: "Bangladesh", co2: 0.5, renewable: 3, population: 166300000, region: "Asia" },
  { name: "South Africa", co2: 8.1, renewable: 7, population: 60400000, region: "Africa" },
  { name: "Turkey", co2: 4.5, renewable: 44, population: 84300000, region: "Europe" },
  { name: "Argentina", co2: 3.6, renewable: 31, population: 45400000, region: "South America" },
  { name: "Italy", co2: 5.2, renewable: 35, population: 60400000, region: "Europe" },
  { name: "Spain", co2: 6.8, renewable: 42, population: 47400000, region: "Europe" },
  { name: "Netherlands", co2: 8.8, renewable: 15, population: 17400000, region: "Europe" },
  { name: "Norway", co2: 7.5, renewable: 98, population: 5400000, region: "Europe" },
  { name: "Sweden", co2: 3.5, renewable: 56, population: 10400000, region: "Europe" },
  { name: "South Korea", co2: 11.6, renewable: 6, population: 51800000, region: "Asia" },
  { name: "Thailand", co2: 3.7, renewable: 12, population: 69800000, region: "Asia" },
  { name: "Vietnam", co2: 2.2, renewable: 9, population: 97300000, region: "Asia" },
  { name: "Egypt", co2: 2.2, renewable: 11, population: 102300000, region: "Africa" },
  { name: "Kenya", co2: 0.3, renewable: 93, population: 54000000, region: "Africa" },
  { name: "Morocco", co2: 1.8, renewable: 37, population: 37500000, region: "Africa" },
];

export default function WorldMap() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRegion, setSelectedRegion] = useState("all");
  const [selectedMetric, setSelectedMetric] = useState("co2");
  const [selectedCountry, setSelectedCountry] = useState<typeof mockCountries[0] | null>(null);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [populationRange, setPopulationRange] = useState([0, 1500]);
  const [co2Range, setCo2Range] = useState([0, 20]);
  const [renewableRange, setRenewableRange] = useState([0, 100]);

  const filteredCountries = mockCountries.filter(country => {
    const matchesSearch = country.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRegion = selectedRegion === "all" || country.region === selectedRegion;
    const matchesPopulation = country.population / 1000000 >= populationRange[0] && country.population / 1000000 <= populationRange[1];
    const matchesCo2 = country.co2 >= co2Range[0] && country.co2 <= co2Range[1];
    const matchesRenewable = country.renewable >= renewableRange[0] && country.renewable <= renewableRange[1];
    return matchesSearch && matchesRegion && matchesPopulation && matchesCo2 && matchesRenewable;
  });

  const regions = Array.from(new Set(mockCountries.map(c => c.region)));

  const getMetricValue = (country: typeof mockCountries[0]) => {
    switch (selectedMetric) {
      case "co2": return `${country.co2} tons/person`;
      case "renewable": return `${country.renewable}%`;
      case "population": return `${(country.population / 1000000).toFixed(1)}M`;
      default: return "";
    }
  };

  const getMetricColor = (country: typeof mockCountries[0]) => {
    switch (selectedMetric) {
      case "co2":
        return country.co2 > 10 ? "bg-red-500" :
               country.co2 > 5 ? "bg-yellow-500" : "bg-green-500";
      case "renewable":
        return country.renewable > 50 ? "bg-green-500" :
               country.renewable > 25 ? "bg-yellow-500" : "bg-red-500";
      default:
        return "bg-blue-500";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 dark:from-blue-950 dark:to-green-950 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 flex items-center justify-center gap-3">
            <Globe className="h-10 w-10 text-blue-600" />
            Global Environmental Data
          </h1>
          <p className="text-xl text-muted-foreground">
            Explore environmental data from over 200 countries worldwide
          </p>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search countries..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={selectedRegion} onValueChange={setSelectedRegion}>
            <SelectTrigger>
              <SelectValue placeholder="Select region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              {regions.map(region => (
                <SelectItem key={region} value={region}>{region}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedMetric} onValueChange={setSelectedMetric}>
            <SelectTrigger>
              <SelectValue placeholder="Select metric" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="co2">CO₂ Emissions</SelectItem>
              <SelectItem value="renewable">Renewable Energy</SelectItem>
              <SelectItem value="population">Population</SelectItem>
            </SelectContent>
          </Select>

          <Dialog open={showAdvancedFilters} onOpenChange={setShowAdvancedFilters}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Filter className="mr-2 h-4 w-4" />
                More Filters
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md" aria-describedby="filter-description">
              <DialogHeader>
                <DialogTitle>Advanced Filters</DialogTitle>
                <DialogDescription id="filter-description">
                  Fine-tune your search with additional filters
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Population Range (millions): {populationRange[0]} - {populationRange[1]}
                  </label>
                  <Slider
                    value={populationRange}
                    onValueChange={setPopulationRange}
                    min={0}
                    max={1500}
                    step={10}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    CO₂ Emissions Range (tons/person): {co2Range[0]} - {co2Range[1]}
                  </label>
                  <Slider
                    value={co2Range}
                    onValueChange={setCo2Range}
                    min={0}
                    max={20}
                    step={0.5}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Renewable Energy Range (%): {renewableRange[0]} - {renewableRange[1]}
                  </label>
                  <Slider
                    value={renewableRange}
                    onValueChange={setRenewableRange}
                    min={0}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => {
                      setPopulationRange([0, 1500]);
                      setCo2Range([0, 20]);
                      setRenewableRange([0, 100]);
                    }}
                  >
                    Reset
                  </Button>
                  <Button 
                    className="flex-1"
                    onClick={() => setShowAdvancedFilters(false)}
                  >
                    Apply Filters
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Country List */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Countries ({filteredCountries.length})</CardTitle>
                <CardDescription>
                  Click on a country to view detailed information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {filteredCountries.map((country, index) => (
                    <div
                      key={country.name}
                      className="flex items-center justify-between p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors"
                      onClick={() => setSelectedCountry(country)}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-4 h-4 rounded-full ${getMetricColor(country)}`} />
                        <div>
                          <h3 className="font-medium">{country.name}</h3>
                          <p className="text-sm text-muted-foreground">{country.region}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">{getMetricValue(country)}</div>
                        <div className="text-sm text-muted-foreground">
                          {selectedMetric === "co2" && "per person"}
                          {selectedMetric === "renewable" && "of total energy"}
                          {selectedMetric === "population" && "people"}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Country Details */}
          <div>
            {selectedCountry ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {selectedCountry.name}
                    <Badge variant="secondary">{selectedCountry.region}</Badge>
                  </CardTitle>
                  <CardDescription>Environmental profile and statistics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-red-50 dark:bg-red-950/20 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">{selectedCountry.co2}</div>
                      <div className="text-sm text-muted-foreground">tons CO₂/person</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 dark:bg-green-950/20 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{selectedCountry.renewable}%</div>
                      <div className="text-sm text-muted-foreground">renewable energy</div>
                    </div>
                  </div>
                  
                  <div className="text-center p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {(selectedCountry.population / 1000000).toFixed(1)}M
                    </div>
                    <div className="text-sm text-muted-foreground">population</div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      {selectedCountry.co2 > 7.4 ? (
                        <TrendingUp className="h-4 w-4 text-red-500" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-green-500" />
                      )}
                      <span className="text-sm">
                        {selectedCountry.co2 > 7.4 ? "Above" : "Below"} global average (7.4 tons)
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {selectedCountry.renewable > 31 ? (
                        <TrendingUp className="h-4 w-4 text-green-500" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-red-500" />
                      )}
                      <span className="text-sm">
                        {selectedCountry.renewable > 31 ? "Above" : "Below"} global average (31%)
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center text-muted-foreground">
                    <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Select a country to view detailed environmental data</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}