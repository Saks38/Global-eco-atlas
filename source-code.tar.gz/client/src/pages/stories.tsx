import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Clock, MapPin, BookOpen } from "lucide-react";

const realStories = [
  {
    id: "1",
    title: "Kenya's Solar Access Project Powers Half a Million People",
    content: "President Ruto launched 14 new project contracts worth ₹5.8 billion ($75 million) in February 2024, establishing 113 mini-grids across 14 marginalized counties including Turkana, Garissa, and Marsabit. The Kenya Off-Grid Solar Access Project (KOSAP) has connected over 1.2 million customers through the Last Mile program, jumping rural electrification from 4% to 75% of households. In Makueni County, the referral hospital's solar system saves ₹1.4 crore annually while providing 30-33% of the hospital's electricity needs. M-KOPA's pay-as-you-go model allows rural households to pay ₹16,000 one-time instead of spending ₹16,000 annually on kerosene lamps, eliminating health hazards from indoor combustion while enabling children to study after dark.",
    country: "Kenya",
    category: "Renewable Energy",
    imageUrl: "https://images.pexels.com/photos/9800082/pexels-photo-9800082.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop",
    readTime: 6,
    excerpt: "Kenya's ambitious Off-Grid Solar Access Project has revolutionized rural energy access, jumping from 4% to 75% household electrification while creating local jobs and saving families ₹16,000 annually on kerosene."
  },
  {
    id: "2",
    title: "Gotham Greens Produces 100 Million Lettuce Heads Annually",
    content: "Brooklyn-based Gotham Greens operates 13 hydroponic greenhouse facilities across 9 states, generating ₹2.7 billion in revenue while producing 100 million heads of lettuce annually. Their Greenpoint Brooklyn facility, opened in 2011, was among the first commercial urban farms, followed by a 20,000 sq ft Gowanus location integrated with Whole Foods. The company's 1.8 million sq ft of facilities distribute to 6,500+ retail locations across all 50 states. Brooklyn Grange manages 2.5 acres of NYC rooftops, distributing 50,000 lbs of fresh produce annually while maintaining the city's largest apiary producing 1,500+ lbs of honey. These operations use 95% less water than traditional farming while eliminating pesticides and reducing transportation from weeks to hours.",
    country: "United States",
    category: "Urban Agriculture",
    imageUrl: "https://images.pexels.com/photos/2933243/pexels-photo-2933243.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop",
    readTime: 7,
    excerpt: "Brooklyn's Gotham Greens revolutionized urban agriculture, generating ₹2.7 billion in revenue while producing 100 million lettuce heads annually across 13 hydroponic facilities, using 95% less water than traditional farming."
  },
  {
    id: "3",
    title: "Manila Bay Restoration Removes 280,000 Tons of Waste",
    content: "The Philippines' massive Manila Bay rehabilitation program has collected over 280,000 tons of waste from more than 37,000 river and coastal cleanups since 2019. Maynilad's Camana Water Reclamation Facility, now 83% complete, will treat 205 million liters of wastewater daily for 1.2 million customers by 2025. The 2024 International Coastal Cleanup achieved record participation with 74,075 volunteers from 1,913 organizations across 250 coastal sites, collecting 352,479 kilograms of trash nationwide. Toledo City's Scubasureros collected only 87 kilos of submerged waste in 2024, down from 240 kilos the previous year, reflecting improved waste management. The Supreme Court's mandated restoration aims to make Manila Bay waters fit for swimming and contact recreation.",
    country: "Philippines",
    category: "Ocean Conservation",
    imageUrl: "https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop",
    readTime: 8,
    excerpt: "The Philippines' court-mandated Manila Bay restoration has removed 280,000 tons of waste through 37,000+ cleanups, with record volunteer participation of 74,075 people collecting 352,479 kg of coastal debris in 2024."
  },
  {
    id: "4",
    title: "Copenhagen Green Roof Mandate Cuts Emissions by 72%",
    content: "Copenhagen's 2010 green roof policy requires all new buildings with roof slopes under 30 degrees to install vegetation, generating 200,000 square meters of green roofs in just two years. The city has reduced CO2 emissions by 72.6% since 2005 while growing its population by 50% since 1990. Each ₹80 spent on climate initiatives generates ₹6,800 in private investment. Green roofs absorb 80% of rainfall, reducing flood risks and urban heat islands while extending roof membrane life by double. With 62% of residents biking to work and 76% of electricity from renewable sources, Copenhagen demonstrates how architectural mandates can drive massive environmental progress, though the ambitious 2025 carbon neutrality target may extend to 2026-2028.",
    country: "Denmark",
    category: "Green Architecture",
    imageUrl: "https://images.pexels.com/photos/323705/pexels-photo-323705.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop",
    readTime: 9,
    excerpt: "Copenhagen's mandatory green roof policy generated 200,000 sq meters of vegetation in two years, contributing to a 72.6% reduction in CO2 emissions while each ₹80 investment generates ₹6,800 in private funding."
  }
];

const categories = Array.from(new Set(realStories.map(story => story.category)));
const countries = Array.from(new Set(realStories.map(story => story.country)));

export default function Stories() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedCountry, setSelectedCountry] = useState("all");
  const [selectedStory, setSelectedStory] = useState<typeof realStories[0] | null>(null);

  const filteredStories = realStories.filter(story => {
    const matchesSearch = story.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         story.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || story.category === selectedCategory;
    const matchesCountry = selectedCountry === "all" || story.country === selectedCountry;
    return matchesSearch && matchesCategory && matchesCountry;
  });

  if (selectedStory) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 p-8">
        <div className="max-w-4xl mx-auto">
          <Button 
            variant="outline" 
            onClick={() => setSelectedStory(null)} 
            className="mb-6"
          >
            ← Back to Stories
          </Button>
          
          <Card>
            <CardHeader>
              <div className="flex flex-wrap gap-2 mb-4">
                <Badge variant="secondary">{selectedStory.category}</Badge>
                <Badge variant="outline">
                  <MapPin className="mr-1 h-3 w-3" />
                  {selectedStory.country}
                </Badge>
                <Badge variant="outline">
                  <Clock className="mr-1 h-3 w-3" />
                  {selectedStory.readTime} min read
                </Badge>
              </div>
              <CardTitle className="text-3xl">{selectedStory.title}</CardTitle>
              <CardDescription className="text-lg mt-4">
                {selectedStory.excerpt}
              </CardDescription>
            </CardHeader>
            <CardContent className="prose dark:prose-invert max-w-none">
              <div className="h-64 mb-6 overflow-hidden rounded-lg">
                <img 
                  src={selectedStory.imageUrl} 
                  alt={selectedStory.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-lg leading-relaxed">
                {selectedStory.content}
              </p>
              <p className="mt-6">
                This story highlights the incredible work being done by communities around the world to address environmental challenges. 
                From grassroots initiatives to innovative technologies, these efforts demonstrate that positive change is possible when 
                people come together with a shared vision for a sustainable future.
              </p>
              <p>
                The success of this initiative provides a model that other communities can adapt and implement in their own contexts. 
                By sharing these stories, we hope to inspire and connect environmental champions worldwide.
              </p>
              

            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 flex items-center justify-center gap-3">
            <BookOpen className="h-10 w-10 text-purple-600" />
            Environmental Stories
          </h1>
          <p className="text-xl text-muted-foreground">
            Inspiring stories of environmental action from around the globe
          </p>
        </div>

        {/* Search and Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search stories..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger>
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedCountry} onValueChange={setSelectedCountry}>
            <SelectTrigger>
              <SelectValue placeholder="All Countries" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Countries</SelectItem>
              {countries.map(country => (
                <SelectItem key={country} value={country}>{country}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="text-center flex items-center justify-center text-sm text-muted-foreground">
            {filteredStories.length} stories found
          </div>
        </div>

        {/* Stories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStories.map((story) => (
            <Card 
              key={story.id} 
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setSelectedStory(story)}
            >
              <CardHeader>
                <div className="h-48 mb-4 overflow-hidden rounded-lg">
                  <img 
                    src={story.imageUrl} 
                    alt={story.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex flex-wrap gap-2 mb-2">
                  <Badge variant="secondary">{story.category}</Badge>
                  <Badge variant="outline">
                    <MapPin className="mr-1 h-3 w-3" />
                    {story.country}
                  </Badge>
                  <Badge variant="outline">
                    <Clock className="mr-1 h-3 w-3" />
                    {story.readTime} min read
                  </Badge>
                </div>
                <CardTitle className="text-lg">{story.title}</CardTitle>
                <CardDescription className="text-sm">
                  {story.excerpt}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center">
                  <span className="text-sm text-muted-foreground">
                    Click to read more
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}