import { useEffect, useState } from "react";
import { Globe, Leaf, Recycle } from "lucide-react";

interface PreloaderProps {
  onComplete: () => void;
}

export function Preloader({ onComplete }: PreloaderProps) {
  const [loadingProgress, setLoadingProgress] = useState(0);

  useEffect(() => {
    // Simulate loading progress
    const interval = setInterval(() => {
      setLoadingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => onComplete(), 500);
          return 100;
        }
        return prev + Math.random() * 12;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-950 dark:to-blue-950">
      <div className="text-center space-y-8">
        {/* Animated Icons */}
        <div className="flex items-center justify-center space-x-6">
          <div className="animate-bounce delay-0">
            <Globe className="h-12 w-12 text-blue-600" />
          </div>
          <div className="animate-bounce delay-150">
            <Leaf className="h-12 w-12 text-green-600" />
          </div>
          <div className="animate-bounce delay-300">
            <Recycle className="h-12 w-12 text-purple-600" />
          </div>
        </div>

        {/* Title */}
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-gray-800 dark:text-gray-200">
            Global Eco Footprint Atlas
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            Loading environmental data from 190+ countries worldwide
          </p>
        </div>

        {/* Progress Bar */}
        <div className="w-80 mx-auto space-y-2">
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full transition-all duration-300 ease-out"
              style={{ width: `${loadingProgress}%` }}
            />
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {Math.round(loadingProgress)}% Complete
          </p>
        </div>

        {/* Loading Messages */}
        <div className="space-y-1">
          <p className="text-sm text-gray-600 dark:text-gray-400 animate-pulse">
            {loadingProgress < 30 && "Initializing environmental database..."}
            {loadingProgress >= 30 && loadingProgress < 60 && "Loading CO₂ emissions data..."}
            {loadingProgress >= 60 && loadingProgress < 90 && "Preparing renewable energy statistics..."}
            {loadingProgress >= 90 && "Almost ready!"}
          </p>
        </div>
      </div>
    </div>
  );
}