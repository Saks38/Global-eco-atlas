import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import {
  Globe,
  Calculator,
  BookOpen,
  BarChart3,
  Users,
  TrendingUp,
  Activity,
  Target,
} from "lucide-react";
import { useAnalytics } from "@/hooks/use-analytics";

export default function Home() {
  const analytics = useAnalytics();

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-blue-50 dark:from-green-950 dark:via-emerald-950 dark:to-blue-950">
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
            Global Eco Footprint Atlas
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Track your environmental impact, explore global data, and join the
            movement toward a sustainable future.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button
              asChild
              size="lg"
              className="bg-green-600 hover:bg-green-700"
            >
              <Link href="/calculator">
                <Calculator className="mr-2 h-5 w-5" />
                Calculate Your Footprint
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/world-map">
                <Globe className="mr-2 h-5 w-5" />
                Explore Global Data
              </Link>
            </Button>
          </div>
        </div>

        {/* Live Analytics Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8 text-gray-900 dark:text-white">
            Live Impact Tracking
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 border-blue-200 dark:border-blue-800">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Users className="h-8 w-8 text-blue-600" />
                  <div>
                    <p className="text-2xl font-bold text-blue-600">
                      {analytics.totalUsers.toLocaleString()}
                    </p>
                    <p className="text-sm text-blue-600/80">Total Users</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900 border-green-200 dark:border-green-800">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Activity className="h-8 w-8 text-green-600" />
                  <div>
                    <p className="text-2xl font-bold text-green-600">
                      {analytics.activeUsers}
                    </p>
                    <p className="text-sm text-green-600/80">Active Now</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900 border-purple-200 dark:border-purple-800">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <TrendingUp className="h-8 w-8 text-purple-600" />
                  <div>
                    <p className="text-2xl font-bold text-purple-600">
                      {analytics.dailyVisitors}
                    </p>
                    <p className="text-sm text-purple-600/80">Daily Visitors</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950 dark:to-orange-900 border-orange-200 dark:border-orange-800">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Calculator className="h-8 w-8 text-orange-600" />
                  <div>
                    <p className="text-2xl font-bold text-orange-600">
                      {analytics.calculationsCompleted.toLocaleString()}
                    </p>
                    <p className="text-sm text-orange-600/80">Calculations</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950 dark:to-emerald-900 border-emerald-200 dark:border-emerald-800">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Target className="h-8 w-8 text-emerald-600" />
                  <div>
                    <p className="text-2xl font-bold text-emerald-600">
                      {analytics.co2Saved.toLocaleString()}
                    </p>
                    <p className="text-sm text-emerald-600/80">kg CO₂ Saved</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          <div className="text-center">
            <Badge variant="secondary" className="px-4 py-2 text-sm">
              <Activity className="w-4 h-4 mr-2" />
              Updates every 10 seconds • Real user activity tracking
            </Badge>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16 max-w-4xl mx-auto">
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardHeader>
              <Calculator className="h-12 w-12 mx-auto text-green-600 mb-4" />
              <CardTitle>Carbon Calculator</CardTitle>
              <CardDescription>
                Calculate your personal carbon footprint with our detailed
                assessment tool
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild variant="outline" className="w-full">
                <Link href="/calculator">Get Started</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardHeader>
              <Globe className="h-12 w-12 mx-auto text-blue-600 mb-4" />
              <CardTitle>World Map</CardTitle>
              <CardDescription>
                Explore environmental data from 190+ countries worldwide
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild variant="outline" className="w-full">
                <Link href="/world-map">Explore</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardHeader>
              <BookOpen className="h-12 w-12 mx-auto text-purple-600 mb-4" />
              <CardTitle>Environmental Stories</CardTitle>
              <CardDescription>
                Read inspiring stories and solutions from around the globe
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild variant="outline" className="w-full">
                <Link href="/stories">Read Stories</Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Global Stats Section */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
          <h2 className="text-3xl font-bold text-center mb-8">
            Global Environmental Impact
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-red-600 mb-2">36.7B</div>
              <div className="text-gray-600 dark:text-gray-400">
                Tons of CO₂ emitted globally (2022)
              </div>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">213</div>
              <div className="text-gray-600 dark:text-gray-400">
                Countries tracked
              </div>
            </div>
            <div>
              <div className="text-4xl font-bold text-green-600 mb-2">4.8T</div>
              <div className="text-gray-600 dark:text-gray-400">
                Average CO₂ per person
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
