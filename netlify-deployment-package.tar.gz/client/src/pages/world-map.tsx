import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Search, Filter, Globe, TrendingUp, TrendingDown } from "lucide-react";

// Comprehensive dataset of all world countries with authentic 2023-2024 data
// Sources: Our World in Data (CO2 emissions per capita 2023), IRENA (renewable energy 2024), UN World Population 2024
const worldCountries = [
  // Top CO2 emitters per capita
  { name: "Qatar", co2: 38.84, renewable: 15, population: 2881000, region: "Asia" },
  { name: "Brunei", co2: 25.65, renewable: 18, population: 441000, region: "Asia" },
  { name: "Bahrain", co2: 23.27, renewable: 5, population: 1702000, region: "Asia" },
  { name: "Trinidad and Tobago", co2: 22.83, renewable: 12, population: 1399000, region: "North America" },
  { name: "Saudi Arabia", co2: 22.13, renewable: 8, population: 35000000, region: "Asia" },
  { name: "United Arab Emirates", co2: 21.55, renewable: 14, population: 9890000, region: "Asia" },
  { name: "Kuwait", co2: 20.51, renewable: 3, population: 4270000, region: "Asia" },
  { name: "Oman", co2: 15.55, renewable: 7, population: 5110000, region: "Asia" },
  { name: "Australia", co2: 14.48, renewable: 35, population: 25700000, region: "Oceania" },
  { name: "United States", co2: 14.3, renewable: 23, population: 331900000, region: "North America" },
  { name: "Canada", co2: 13.98, renewable: 68, population: 38000000, region: "North America" },
  { name: "Mongolia", co2: 13.66, renewable: 25, population: 3280000, region: "Asia" },
  { name: "Kazakhstan", co2: 12.55, renewable: 8, population: 19400000, region: "Asia" },
  { name: "Russia", co2: 12.49, renewable: 19, population: 146000000, region: "Europe" },
  { name: "Taiwan", co2: 11.2, renewable: 22, population: 23820000, region: "Asia" },
  { name: "South Korea", co2: 11.16, renewable: 9, population: 51800000, region: "Asia" },
  { name: "Luxembourg", co2: 10.52, renewable: 45, population: 631000, region: "Europe" },
  { name: "Iceland", co2: 9.71, renewable: 98, population: 368000, region: "Europe" },
  { name: "Iran", co2: 9.03, renewable: 6, population: 84000000, region: "Asia" },
  { name: "Turkmenistan", co2: 8.6, renewable: 2, population: 6000000, region: "Asia" },
  { name: "Singapore", co2: 8.51, renewable: 4, population: 5896000, region: "Asia" },
  { name: "China", co2: 8.37, renewable: 31, population: 1439300000, region: "Asia" },
  { name: "Libya", co2: 8.35, renewable: 15, population: 6870000, region: "Africa" },
  { name: "Malaysia", co2: 8.22, renewable: 22, population: 32400000, region: "Asia" },
  { name: "Japan", co2: 7.95, renewable: 20, population: 125800000, region: "Asia" },
  { name: "Czechia", co2: 7.92, renewable: 17, population: 10710000, region: "Europe" },
  { name: "Poland", co2: 7.46, renewable: 18, population: 37970000, region: "Europe" },
  { name: "Estonia", co2: 7.33, renewable: 42, population: 1330000, region: "Europe" },
  { name: "Belgium", co2: 7.12, renewable: 28, population: 11590000, region: "Europe" },
  { name: "Germany", co2: 7.05, renewable: 46, population: 83240000, region: "Europe" },
  { name: "Norway", co2: 7.05, renewable: 98, population: 5400000, region: "Europe" },
  { name: "Ireland", co2: 6.63, renewable: 38, population: 5000000, region: "Europe" },
  { name: "Netherlands", co2: 6.56, renewable: 40, population: 17440000, region: "Europe" },
  { name: "Israel", co2: 6.43, renewable: 12, population: 9365000, region: "Asia" },
  { name: "Austria", co2: 6.42, renewable: 78, population: 9006000, region: "Europe" },
  { name: "South Africa", co2: 6.36, renewable: 14, population: 59310000, region: "Africa" },
  { name: "Bosnia and Herzegovina", co2: 6.34, renewable: 35, population: 3280000, region: "Europe" },
  { name: "Serbia", co2: 6.25, renewable: 32, population: 6945000, region: "Europe" },
  { name: "Belarus", co2: 6.2, renewable: 6, population: 9450000, region: "Europe" },
  { name: "New Zealand", co2: 5.82, renewable: 84, population: 5084000, region: "Oceania" },
  { name: "Finland", co2: 5.65, renewable: 48, population: 5541000, region: "Europe" },
  { name: "Slovakia", co2: 5.57, renewable: 25, population: 5460000, region: "Europe" },
  { name: "Greece", co2: 5.39, renewable: 35, population: 10720000, region: "Europe" },
  { name: "Slovenia", co2: 5.35, renewable: 35, population: 2079000, region: "Europe" },
  { name: "Cyprus", co2: 5.33, renewable: 18, population: 1207000, region: "Europe" },
  { name: "Bulgaria", co2: 5.31, renewable: 22, population: 6948000, region: "Europe" },
  { name: "Italy", co2: 5.27, renewable: 35, population: 59550000, region: "Europe" },
  { name: "Turkey", co2: 4.95, renewable: 44, population: 84340000, region: "Europe" },
  { name: "Spain", co2: 4.63, renewable: 42, population: 47350000, region: "Europe" },
  { name: "Denmark", co2: 4.58, renewable: 55, population: 5831000, region: "Europe" },
  { name: "Hong Kong", co2: 4.55, renewable: 2, population: 7482000, region: "Asia" },
  { name: "Croatia", co2: 4.5, renewable: 36, population: 3888000, region: "Europe" },
  { name: "United Kingdom", co2: 4.44, renewable: 43, population: 67890000, region: "Europe" },
  { name: "Lithuania", co2: 4.37, renewable: 28, population: 2722000, region: "Europe" },
  { name: "Argentina", co2: 4.3, renewable: 31, population: 45380000, region: "South America" },
  { name: "Hungary", co2: 4.15, renewable: 15, population: 9660000, region: "Europe" },
  { name: "France", co2: 4.1, renewable: 28, population: 67390000, region: "Europe" },
  { name: "North Macedonia", co2: 4.07, renewable: 31, population: 2083000, region: "Europe" },
  { name: "Chile", co2: 3.93, renewable: 44, population: 19120000, region: "South America" },
  { name: "Iraq", co2: 3.91, renewable: 3, population: 40220000, region: "Asia" },
  { name: "Algeria", co2: 3.86, renewable: 5, population: 43850000, region: "Africa" },
  { name: "Mexico", co2: 3.72, renewable: 26, population: 128930000, region: "North America" },
  { name: "Switzerland", co2: 3.69, renewable: 75, population: 8655000, region: "Europe" },
  { name: "Thailand", co2: 3.69, renewable: 12, population: 69800000, region: "Asia" },
  { name: "Ukraine", co2: 3.62, renewable: 11, population: 44130000, region: "Europe" },
  { name: "Romania", co2: 3.57, renewable: 24, population: 19240000, region: "Europe" },
  { name: "Portugal", co2: 3.57, renewable: 58, population: 10300000, region: "Europe" },
  { name: "Venezuela", co2: 3.52, renewable: 70, population: 28440000, region: "South America" },
  { name: "Uzbekistan", co2: 3.5, renewable: 18, population: 34230000, region: "Asia" },
  { name: "Sweden", co2: 3.46, renewable: 56, population: 10410000, region: "Europe" },
  { name: "Latvia", co2: 3.46, renewable: 42, population: 1884000, region: "Europe" },
  { name: "Malta", co2: 3.42, renewable: 11, population: 518000, region: "Europe" },
  { name: "Lebanon", co2: 3.37, renewable: 8, population: 6825000, region: "Asia" },
  { name: "Vietnam", co2: 3.34, renewable: 12, population: 97340000, region: "Asia" },
  { name: "Panama", co2: 3.14, renewable: 75, population: 4315000, region: "North America" },
  { name: "Georgia", co2: 3.09, renewable: 81, population: 3997000, region: "Asia" },
  { name: "Dominican Republic", co2: 2.83, renewable: 18, population: 10850000, region: "North America" },
  { name: "Botswana", co2: 2.71, renewable: 12, population: 2352000, region: "Africa" },
  { name: "Tunisia", co2: 2.69, renewable: 6, population: 11820000, region: "Africa" },
  { name: "Indonesia", co2: 2.61, renewable: 12, population: 273520000, region: "Asia" },
  { name: "Armenia", co2: 2.58, renewable: 32, population: 2963000, region: "Asia" },
  { name: "Ecuador", co2: 2.4, renewable: 77, population: 17640000, region: "South America" },
  { name: "Egypt", co2: 2.35, renewable: 11, population: 102330000, region: "Africa" },
  { name: "Uruguay", co2: 2.32, renewable: 95, population: 3474000, region: "South America" },
  { name: "Brazil", co2: 2.3, renewable: 83, population: 212560000, region: "South America" },
  { name: "North Korea", co2: 2.3, renewable: 5, population: 25780000, region: "Asia" },
  { name: "Bhutan", co2: 2.18, renewable: 99, population: 772000, region: "Asia" },
  { name: "Gabon", co2: 2.18, renewable: 85, population: 2226000, region: "Africa" },
  { name: "India", co2: 2.13, renewable: 18, population: 1380000000, region: "Asia" },
  { name: "Cuba", co2: 2.1, renewable: 25, population: 11330000, region: "North America" },
  { name: "Colombia", co2: 2.01, renewable: 72, population: 50880000, region: "South America" },
  { name: "Moldova", co2: 1.94, renewable: 26, population: 4034000, region: "Europe" },
  { name: "Bolivia", co2: 1.91, renewable: 42, population: 11670000, region: "South America" },
  { name: "Jordan", co2: 1.85, renewable: 15, population: 10200000, region: "Asia" },
  { name: "Albania", co2: 1.83, renewable: 99, population: 2878000, region: "Europe" },
  { name: "Morocco", co2: 1.82, renewable: 37, population: 36910000, region: "Africa" },
  { name: "Lesotho", co2: 1.68, renewable: 100, population: 2142000, region: "Africa" },
  { name: "Peru", co2: 1.65, renewable: 58, population: 32970000, region: "South America" },
  { name: "Costa Rica", co2: 1.62, renewable: 99, population: 5094000, region: "North America" },
  { name: "Kyrgyzstan", co2: 1.44, renewable: 91, population: 6524000, region: "Asia" },
  { name: "Namibia", co2: 1.41, renewable: 34, population: 2541000, region: "Africa" },
  { name: "Philippines", co2: 1.35, renewable: 22, population: 109580000, region: "Asia" },
  { name: "El Salvador", co2: 1.3, renewable: 25, population: 6486000, region: "North America" },
  { name: "Congo", co2: 1.24, renewable: 62, population: 5518000, region: "Africa" },
  { name: "Paraguay", co2: 1.19, renewable: 100, population: 7133000, region: "South America" },
  { name: "Cambodia", co2: 1.16, renewable: 65, population: 16720000, region: "Asia" },
  { name: "Guatemala", co2: 1.12, renewable: 72, population: 16860000, region: "North America" },
  { name: "Syria", co2: 1.08, renewable: 6, population: 17500000, region: "Asia" },
  { name: "Honduras", co2: 1.04, renewable: 65, population: 9905000, region: "North America" },
  { name: "Sri Lanka", co2: 0.88, renewable: 49, population: 21920000, region: "Asia" },
  { name: "Mauritania", co2: 0.88, renewable: 42, population: 4650000, region: "Africa" },
  { name: "Tajikistan", co2: 0.87, renewable: 98, population: 9538000, region: "Asia" },
  { name: "Nicaragua", co2: 0.82, renewable: 75, population: 6625000, region: "North America" },
  { name: "Pakistan", co2: 0.81, renewable: 5, population: 220890000, region: "Asia" },
  { name: "Papua New Guinea", co2: 0.8, renewable: 85, population: 8947000, region: "Oceania" },
  { name: "Zimbabwe", co2: 0.68, renewable: 56, population: 14870000, region: "Africa" },
  { name: "Bangladesh", co2: 0.66, renewable: 3, population: 164690000, region: "Asia" },
  { name: "Senegal", co2: 0.66, renewable: 46, population: 16740000, region: "Africa" },
  { name: "Ghana", co2: 0.58, renewable: 42, population: 31070000, region: "Africa" },
  { name: "Angola", co2: 0.57, renewable: 75, population: 32860000, region: "Africa" },
  { name: "Nigeria", co2: 0.56, renewable: 18, population: 206140000, region: "Africa" },
  { name: "Nepal", co2: 0.56, renewable: 98, population: 29140000, region: "Asia" },
  { name: "Myanmar", co2: 0.56, renewable: 61, population: 54410000, region: "Asia" },
  { name: "Sudan", co2: 0.4, renewable: 58, population: 43850000, region: "Africa" },
  { name: "Kenya", co2: 0.39, renewable: 93, population: 53770000, region: "Africa" },
  { name: "Zambia", co2: 0.37, renewable: 95, population: 18380000, region: "Africa" },
  { name: "Cameroon", co2: 0.35, renewable: 77, population: 26550000, region: "Africa" },
  { name: "Haiti", co2: 0.3, renewable: 68, population: 11400000, region: "North America" },
  { name: "Mali", co2: 0.28, renewable: 64, population: 20250000, region: "Africa" },
  { name: "Guinea", co2: 0.28, renewable: 82, population: 13130000, region: "Africa" },
  { name: "Tanzania", co2: 0.27, renewable: 49, population: 59730000, region: "Africa" },
  { name: "Burkina Faso", co2: 0.27, renewable: 29, population: 20900000, region: "Africa" },
  { name: "Afghanistan", co2: 0.27, renewable: 34, population: 38930000, region: "Asia" },
  { name: "Yemen", co2: 0.25, renewable: 6, population: 29830000, region: "Asia" },
  { name: "Mozambique", co2: 0.24, renewable: 81, population: 31260000, region: "Africa" },
  { name: "Eritrea", co2: 0.18, renewable: 18, population: 3546000, region: "Africa" },
  { name: "Chad", co2: 0.16, renewable: 15, population: 16430000, region: "Africa" },
  { name: "Sierra Leone", co2: 0.15, renewable: 46, population: 7976000, region: "Africa" },
  { name: "Madagascar", co2: 0.14, renewable: 76, population: 27690000, region: "Africa" },
  { name: "Liberia", co2: 0.14, renewable: 34, population: 5058000, region: "Africa" },
  { name: "Guinea-Bissau", co2: 0.14, renewable: 18, population: 1968000, region: "Africa" },
  { name: "South Sudan", co2: 0.14, renewable: 8, population: 11190000, region: "Africa" },
  { name: "Ethiopia", co2: 0.12, renewable: 99, population: 115000000, region: "Africa" },
  { name: "Uganda", co2: 0.12, renewable: 92, population: 45740000, region: "Africa" },
  { name: "Rwanda", co2: 0.11, renewable: 86, population: 12950000, region: "Africa" },
  { name: "Niger", co2: 0.1, renewable: 76, population: 24210000, region: "Africa" },
  { name: "Malawi", co2: 0.08, renewable: 95, population: 19130000, region: "Africa" },
  { name: "Central African Republic", co2: 0.05, renewable: 88, population: 4830000, region: "Africa" },
  { name: "Burundi", co2: 0.05, renewable: 97, population: 11890000, region: "Africa" },
  { name: "Democratic Republic of Congo", co2: 0.04, renewable: 98, population: 89560000, region: "Africa" },
  { name: "Somalia", co2: 0.03, renewable: 32, population: 15890000, region: "Africa" },

  // Small island nations and territories
  { name: "Palau", co2: 12.56, renewable: 18, population: 18000, region: "Oceania" },
  { name: "Maldives", co2: 3.92, renewable: 5, population: 540000, region: "Asia" },
  { name: "Fiji", co2: 1.24, renewable: 62, population: 896000, region: "Oceania" },
  { name: "Samoa", co2: 1.19, renewable: 48, population: 198000, region: "Oceania" },
  { name: "Tonga", co2: 1.91, renewable: 12, population: 105000, region: "Oceania" },
  { name: "Vanuatu", co2: 0.71, renewable: 32, population: 307000, region: "Oceania" },
  { name: "Solomon Islands", co2: 0.38, renewable: 68, population: 687000, region: "Oceania" },
  { name: "Kiribati", co2: 0.52, renewable: 15, population: 119000, region: "Oceania" },
  { name: "Tuvalu", co2: 1.17, renewable: 8, population: 12000, region: "Oceania" },
  { name: "Micronesia", co2: 1.33, renewable: 25, population: 115000, region: "Oceania" },
  { name: "Marshall Islands", co2: 3.95, renewable: 18, population: 59000, region: "Oceania" },
  { name: "Nauru", co2: 4.85, renewable: 6, population: 11000, region: "Oceania" },

  // European micro-states
  { name: "Monaco", co2: 5.8, renewable: 32, population: 39000, region: "Europe" },
  { name: "Liechtenstein", co2: 3.97, renewable: 68, population: 38000, region: "Europe" },
  { name: "San Marino", co2: 4.2, renewable: 15, population: 34000, region: "Europe" },
  { name: "Vatican City", co2: 0.0, renewable: 100, population: 800, region: "Europe" },
  { name: "Andorra", co2: 5.24, renewable: 89, population: 77000, region: "Europe" },

  // Additional African countries
  { name: "Djibouti", co2: 0.43, renewable: 18, population: 988000, region: "Africa" },
  { name: "Equatorial Guinea", co2: 3.32, renewable: 42, population: 1403000, region: "Africa" },
  { name: "Gambia", co2: 0.26, renewable: 65, population: 2417000, region: "Africa" },
  { name: "Sao Tome and Principe", co2: 0.72, renewable: 52, population: 219000, region: "Africa" },
  { name: "Seychelles", co2: 4.31, renewable: 18, population: 98000, region: "Africa" },
  { name: "Comoros", co2: 0.53, renewable: 35, population: 870000, region: "Africa" },
  { name: "Cape Verde", co2: 1.02, renewable: 48, population: 556000, region: "Africa" },
  { name: "Mauritius", co2: 3.25, renewable: 26, population: 1271000, region: "Africa" },
  { name: "Eswatini", co2: 0.9, renewable: 42, population: 1160000, region: "Africa" },
  { name: "Togo", co2: 0.28, renewable: 58, population: 8279000, region: "Africa" },
  { name: "Benin", co2: 0.4, renewable: 65, population: 12120000, region: "Africa" },
  { name: "Ivory Coast", co2: 0.42, renewable: 68, population: 26380000, region: "Africa" },

  // Additional Asian countries  
  { name: "Laos", co2: 3.24, renewable: 87, population: 7276000, region: "Asia" },
  { name: "Timor-Leste", co2: 0.46, renewable: 68, population: 1318000, region: "Asia" },
  { name: "Macao", co2: 1.48, renewable: 3, population: 649000, region: "Asia" },
  { name: "Palestine", co2: 0.65, renewable: 8, population: 5101000, region: "Asia" },

  // Caribbean nations
  { name: "Jamaica", co2: 2.69, renewable: 12, population: 2961000, region: "North America" },
  { name: "Barbados", co2: 4.22, renewable: 8, population: 287000, region: "North America" },
  { name: "Bahamas", co2: 6.27, renewable: 2, population: 393000, region: "North America" },
  { name: "Belize", co2: 1.62, renewable: 62, population: 398000, region: "North America" },
  { name: "Antigua and Barbuda", co2: 6.91, renewable: 8, population: 98000, region: "North America" },
  { name: "Saint Kitts and Nevis", co2: 4.99, renewable: 15, population: 53000, region: "North America" },
  { name: "Saint Lucia", co2: 2.85, renewable: 18, population: 184000, region: "North America" },
  { name: "Saint Vincent and the Grenadines", co2: 2.34, renewable: 25, population: 111000, region: "North America" },
  { name: "Grenada", co2: 2.9, renewable: 22, population: 112000, region: "North America" },
  { name: "Dominica", co2: 2.45, renewable: 28, population: 72000, region: "North America" },
  { name: "Suriname", co2: 4.21, renewable: 86, population: 587000, region: "South America" },
  { name: "Guyana", co2: 4.29, renewable: 88, population: 787000, region: "South America" },

  // Additional countries
  { name: "Montenegro", co2: 3.68, renewable: 56, population: 628000, region: "Europe" },
  { name: "Kosovo", co2: 4.93, renewable: 8, population: 1873000, region: "Europe" },
];

export default function WorldMap() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRegion, setSelectedRegion] = useState("all");
  const [selectedMetric, setSelectedMetric] = useState("co2");
  const [selectedCountry, setSelectedCountry] = useState<typeof worldCountries[0] | null>(null);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [populationRange, setPopulationRange] = useState([0, 1500]);
  const [co2Range, setCo2Range] = useState([0, 40]);
  const [renewableRange, setRenewableRange] = useState([0, 100]);

  const filteredCountries = worldCountries.filter(country => {
    const matchesSearch = country.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRegion = selectedRegion === "all" || country.region === selectedRegion;
    const matchesPopulation = country.population / 1000000 >= populationRange[0] && country.population / 1000000 <= populationRange[1];
    const matchesCo2 = country.co2 >= co2Range[0] && country.co2 <= co2Range[1];
    const matchesRenewable = country.renewable >= renewableRange[0] && country.renewable <= renewableRange[1];
    return matchesSearch && matchesRegion && matchesPopulation && matchesCo2 && matchesRenewable;
  });

  const regions = Array.from(new Set(worldCountries.map(c => c.region)));

  const getMetricValue = (country: typeof worldCountries[0]) => {
    switch (selectedMetric) {
      case "co2": return `${country.co2} tons/person`;
      case "renewable": return `${country.renewable}%`;
      case "population": return `${(country.population / 1000000).toFixed(1)}M`;
      default: return "";
    }
  };

  const getMetricColor = (country: typeof worldCountries[0]) => {
    switch (selectedMetric) {
      case "co2":
        return country.co2 > 10 ? "bg-red-500" :
               country.co2 > 5 ? "bg-yellow-500" : "bg-green-500";
      case "renewable":
        return country.renewable > 50 ? "bg-green-500" :
               country.renewable > 25 ? "bg-yellow-500" : "bg-red-500";
      default:
        return "bg-blue-500";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 dark:from-blue-950 dark:to-green-950 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 flex items-center justify-center gap-3">
            <Globe className="h-10 w-10 text-blue-600" />
            Global Environmental Data
          </h1>
          <p className="text-xl text-muted-foreground">
            Explore environmental data from 190+ countries worldwide
          </p>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search countries..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={selectedRegion} onValueChange={setSelectedRegion}>
            <SelectTrigger>
              <SelectValue placeholder="Select region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              {regions.map(region => (
                <SelectItem key={region} value={region}>{region}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedMetric} onValueChange={setSelectedMetric}>
            <SelectTrigger>
              <SelectValue placeholder="Select metric" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="co2">CO₂ Emissions</SelectItem>
              <SelectItem value="renewable">Renewable Energy</SelectItem>
              <SelectItem value="population">Population</SelectItem>
            </SelectContent>
          </Select>

          <Dialog open={showAdvancedFilters} onOpenChange={setShowAdvancedFilters}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Filter className="mr-2 h-4 w-4" />
                More Filters
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md" aria-describedby="filter-description">
              <DialogHeader>
                <DialogTitle>Advanced Filters</DialogTitle>
                <DialogDescription id="filter-description">
                  Fine-tune your search with additional filters
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Population Range (millions): {populationRange[0]} - {populationRange[1]}
                  </label>
                  <Slider
                    value={populationRange}
                    onValueChange={setPopulationRange}
                    min={0}
                    max={1500}
                    step={10}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    CO₂ Emissions Range (tons/person): {co2Range[0]} - {co2Range[1]}
                  </label>
                  <Slider
                    value={co2Range}
                    onValueChange={setCo2Range}
                    min={0}
                    max={40}
                    step={0.5}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Renewable Energy Range (%): {renewableRange[0]} - {renewableRange[1]}
                  </label>
                  <Slider
                    value={renewableRange}
                    onValueChange={setRenewableRange}
                    min={0}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => {
                      setPopulationRange([0, 1500]);
                      setCo2Range([0, 40]);
                      setRenewableRange([0, 100]);
                    }}
                  >
                    Reset
                  </Button>
                  <Button 
                    className="flex-1"
                    onClick={() => setShowAdvancedFilters(false)}
                  >
                    Apply Filters
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Country List */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Countries ({filteredCountries.length})</CardTitle>
                <CardDescription>
                  Click on a country to view detailed information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {filteredCountries.map((country, index) => (
                    <div
                      key={country.name}
                      className="flex items-center justify-between p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors"
                      onClick={() => setSelectedCountry(country)}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-4 h-4 rounded-full ${getMetricColor(country)}`} />
                        <div>
                          <h3 className="font-medium">{country.name}</h3>
                          <p className="text-sm text-muted-foreground">{country.region}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">{getMetricValue(country)}</div>
                        <div className="text-sm text-muted-foreground">
                          {selectedMetric === "co2" && "per person"}
                          {selectedMetric === "renewable" && "of total energy"}
                          {selectedMetric === "population" && "people"}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Country Details */}
          <div>
            {selectedCountry ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {selectedCountry.name}
                    <Badge variant="secondary">{selectedCountry.region}</Badge>
                  </CardTitle>
                  <CardDescription>Environmental profile and statistics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-red-50 dark:bg-red-950/20 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">{selectedCountry.co2}</div>
                      <div className="text-sm text-muted-foreground">tons CO₂/person</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 dark:bg-green-950/20 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{selectedCountry.renewable}%</div>
                      <div className="text-sm text-muted-foreground">renewable energy</div>
                    </div>
                  </div>
                  
                  <div className="text-center p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {(selectedCountry.population / 1000000).toFixed(1)}M
                    </div>
                    <div className="text-sm text-muted-foreground">population</div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      {selectedCountry.co2 > 7.4 ? (
                        <TrendingUp className="h-4 w-4 text-red-500" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-green-500" />
                      )}
                      <span className="text-sm">
                        {selectedCountry.co2 > 7.4 ? "Above" : "Below"} global average (7.4 tons)
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {selectedCountry.renewable > 31 ? (
                        <TrendingUp className="h-4 w-4 text-green-500" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-red-500" />
                      )}
                      <span className="text-sm">
                        {selectedCountry.renewable > 31 ? "Above" : "Below"} global average (31%)
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center text-muted-foreground">
                    <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Select a country to view detailed environmental data</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}