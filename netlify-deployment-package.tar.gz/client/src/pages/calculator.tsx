import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Car, Home, Utensils, ShoppingBag, ArrowLeft, ArrowRight, Lightbulb, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { getCarbonTips } from "@/utils/carbon-tips";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

const steps = [
  { id: 1, title: "Transportation", icon: Car },
  { id: 2, title: "Energy", icon: Home },
  { id: 3, title: "Food", icon: Utensils },
  { id: 4, title: "Consumption", icon: ShoppingBag },
];

export default function Calculator() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    transportation: { carMiles: "", flightHours: "", publicTransport: "" },
    energy: { homeSize: "", energySource: "", monthlyBill: "" },
    food: { diet: "", meatFrequency: "", localFood: "" },
    consumption: { shopping: "", electronics: "", secondHand: "" },
  });
  const [results, setResults] = useState<any>(null);

  const updateFormData = (step: string, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [step]: { ...prev[step as keyof typeof prev], [field]: value }
    }));
  };

  const calculateFootprint = () => {
    // Simple calculation logic
    const transport = (parseInt(formData.transportation.carMiles) || 0) * 0.4 + 
                     (parseInt(formData.transportation.flightHours) || 0) * 0.9;
    const energy = (parseInt(formData.energy.monthlyBill) || 0) * 0.1;
    const food = formData.food.diet === "meat-heavy" ? 2.5 : 
                 formData.food.diet === "vegetarian" ? 1.2 : 1.8;
    const consumption = formData.consumption.shopping === "high" ? 1.5 : 
                       formData.consumption.shopping === "low" ? 0.5 : 1.0;
    
    const total = transport + energy + food + consumption;
    
    // Save calculation to localStorage for real analytics tracking
    const calculations = localStorage.getItem('eco-calculations');
    const calcHistory = calculations ? JSON.parse(calculations) : [];
    calcHistory.push({
      id: Math.random().toString(36),
      timestamp: Date.now(),
      total,
      breakdown: { transport, energy, food, consumption }
    });
    localStorage.setItem('eco-calculations', JSON.stringify(calcHistory));
    
    // Generate personalized carbon tips based on user choices
    const userChoices = {
      transportation: formData.transportation.carMiles ? 'car' : 'public',
      homeSize: formData.energy.homeSize,
      energySource: formData.energy.energySource === 'renewable' ? 'renewable' : 'fossil',
      diet: formData.food.diet,
      recycling: 'sometimes' // default for demo
    };
    
    const tips = getCarbonTips(userChoices);
    
    setResults({ total, transport, energy, food, consumption, tips });
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="carMiles">Car kilometers per week</Label>
              <Input
                id="carMiles"
                type="number"
                placeholder="e.g., 240"
                value={formData.transportation.carMiles}
                onChange={(e) => updateFormData("transportation", "carMiles", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="flightHours">Flight hours per year</Label>
              <Input
                id="flightHours"
                type="number"
                placeholder="e.g., 10"
                value={formData.transportation.flightHours}
                onChange={(e) => updateFormData("transportation", "flightHours", e.target.value)}
              />
            </div>
            <div>
              <Label>Public transport usage</Label>
              <Select
                value={formData.transportation.publicTransport}
                onValueChange={(value) => updateFormData("transportation", "publicTransport", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select usage frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="rarely">Rarely</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-4">
            <div>
              <Label>Home size</Label>
              <Select
                value={formData.energy.homeSize}
                onValueChange={(value) => updateFormData("energy", "homeSize", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select home size" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="small">Small (&lt; 1000 sq ft)</SelectItem>
                  <SelectItem value="medium">Medium (1000-2000 sq ft)</SelectItem>
                  <SelectItem value="large">Large (&gt; 2000 sq ft)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Energy source</Label>
              <Select
                value={formData.energy.energySource}
                onValueChange={(value) => updateFormData("energy", "energySource", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select energy source" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="renewable">Mostly renewable</SelectItem>
                  <SelectItem value="mixed">Mixed sources</SelectItem>
                  <SelectItem value="fossil">Mostly fossil fuels</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="monthlyBill">Monthly energy bill (₹)</Label>
              <Input
                id="monthlyBill"
                type="number"
                placeholder="e.g., 10000"
                value={formData.energy.monthlyBill}
                onChange={(e) => updateFormData("energy", "monthlyBill", e.target.value)}
              />
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-4">
            <div>
              <Label>Diet type</Label>
              <Select
                value={formData.food.diet}
                onValueChange={(value) => updateFormData("food", "diet", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select diet type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="meat-heavy">Meat-heavy</SelectItem>
                  <SelectItem value="omnivore">Balanced omnivore</SelectItem>
                  <SelectItem value="vegetarian">Vegetarian</SelectItem>
                  <SelectItem value="vegan">Vegan</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Local/organic food preference</Label>
              <Select
                value={formData.food.localFood}
                onValueChange={(value) => updateFormData("food", "localFood", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select preference" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="always">Always when possible</SelectItem>
                  <SelectItem value="sometimes">Sometimes</SelectItem>
                  <SelectItem value="rarely">Rarely</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-4">
            <div>
              <Label>Shopping habits</Label>
              <Select
                value={formData.consumption.shopping}
                onValueChange={(value) => updateFormData("consumption", "shopping", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select shopping frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High - frequent purchases</SelectItem>
                  <SelectItem value="medium">Medium - moderate purchases</SelectItem>
                  <SelectItem value="low">Low - minimal purchases</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Second-hand purchases</Label>
              <Select
                value={formData.consumption.secondHand}
                onValueChange={(value) => updateFormData("consumption", "secondHand", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="often">Often</SelectItem>
                  <SelectItem value="sometimes">Sometimes</SelectItem>
                  <SelectItem value="never">Never</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  const validateCurrentStep = () => {
    const currentStepData = Object.values(formData)[currentStep - 1];
    const hasAnyValue = Object.values(currentStepData).some(value => value && value.trim() !== '');
    return hasAnyValue;
  };

  const nextStep = () => {
    if (!validateCurrentStep()) {
      alert('Please fill in at least one field before continuing.');
      return;
    }
    
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    } else {
      calculateFootprint();
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  if (results) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-950 dark:to-blue-950 p-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-4">Your Carbon Footprint Results</h1>
            <p className="text-xl text-muted-foreground">Here's your environmental impact breakdown</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-3xl text-green-600">{results.total.toFixed(1)} tons</CardTitle>
                <CardDescription>Total CO₂ per year</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Global average: 4.8 tons per person
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Breakdown by Category</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span>Transportation</span>
                  <span className="font-bold">{results.transport.toFixed(1)} tons</span>
                </div>
                <div className="flex justify-between">
                  <span>Energy</span>
                  <span className="font-bold">{results.energy.toFixed(1)} tons</span>
                </div>
                <div className="flex justify-between">
                  <span>Food</span>
                  <span className="font-bold">{results.food.toFixed(1)} tons</span>
                </div>
                <div className="flex justify-between">
                  <span>Consumption</span>
                  <span className="font-bold">{results.consumption.toFixed(1)} tons</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Personalized Carbon Reduction Tips */}
          {results.tips && results.tips.length > 0 && (
            <div className="mb-8">
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Lightbulb className="h-6 w-6 text-yellow-500" />
                    <CardTitle>Personalized Tips to Reduce Your Footprint</CardTitle>
                  </div>
                  <CardDescription>
                    Based on your responses, here are specific actions you can take to lower your environmental impact:
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {results.tips.map((tip: any, index: number) => (
                      <Alert key={index} className="border-l-4 border-l-green-500">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">
                                {tip.category}
                              </Badge>
                              <Badge 
                                variant={tip.difficulty === 'Easy' ? 'default' : tip.difficulty === 'Medium' ? 'secondary' : 'destructive'}
                                className="text-xs"
                              >
                                {tip.difficulty}
                              </Badge>
                            </div>
                            <p className="font-medium">{tip.tip}</p>
                            <p className="text-sm text-green-600 font-medium">💡 {tip.impact}</p>
                          </div>
                        </AlertDescription>
                      </Alert>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <div className="text-center space-y-4">
            <Button onClick={() => { setResults(null); setCurrentStep(1); }} size="lg">
              Calculate Again
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/stories">Read Environmental Stories</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-950 dark:to-blue-950 p-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">Carbon Footprint Calculator</h1>
          <p className="text-xl text-muted-foreground">Calculate your environmental impact in 4 easy steps</p>
        </div>

        {/* Progress indicator */}
        <div className="mb-8">
          <div className="flex justify-between mb-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={step.id} className="flex flex-col items-center">
                  <div className={`rounded-full p-3 mb-2 ${
                    currentStep >= step.id ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <span className="text-sm font-medium">{step.title}</span>
                </div>
              );
            })}
          </div>
          <Progress value={(currentStep / 4) * 100} className="h-2" />
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{steps[currentStep - 1].title}</CardTitle>
            <CardDescription>
              Step {currentStep} of 4: Tell us about your {steps[currentStep - 1].title.toLowerCase()} habits
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {renderStep()}
            
            <Separator />
            
            <div className="flex justify-between">
              <Button 
                variant="outline" 
                onClick={prevStep} 
                disabled={currentStep === 1}
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>
              <Button onClick={nextStep}>
                {currentStep === 4 ? 'Calculate Results' : 'Next'}
                {currentStep < 4 && <ArrowRight className="ml-2 h-4 w-4" />}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}