import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Heart, Clock, MapPin, BookOpen } from "lucide-react";

const mockStories = [
  {
    id: "1",
    title: "Solar Revolution in Rural Kenya",
    content: "How small villages are leading Africa's renewable energy transformation through community-owned solar grids.",
    country: "Kenya",
    category: "Renewable Energy",
    imageUrl: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MDAiIGhlaWdodD0iMjAwIiB2aWV3Qm94PSIwIDAgNDAwIDIwMCI+PHJlY3Qgd2lkdGg9IjQwMCIgaGVpZ2h0PSIyMDAiIGZpbGw9IiNGRkI4MDAiLz48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxNTAsNTApIj48Y2lyY2xlIGN4PSI1MCIgY3k9IjMwIiByPSIyMCIgZmlsbD0iI0ZGNkIwMCIvPjxwYXRoIGQ9Ik0zMCA1MCBMNTDUCA1MUwzNSA4MFoiIGZpbGw9IiM0MTY5RTEiLz48cGF0aCBkPSJNNTAgMzAgTDQ1IDE1IE01MCAzMCBMMzUgMjAgTTUwIDMwIEw2NSAyMCBNNTAgzMCBMNTUgMTUiIHN0cm9rZT0iI0ZGNkIwMCIgc3Ryb2tlLXdpZHRoPSIyIi8+PC9nPjx0ZXh0IHg9IjIwIiB5PSIxODAiIGZpbGw9IndoaXRlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTQiPlNvbGFyIEVuZXJneSBpbiBLZW55YTwvdGV4dD48L3N2Zz4=",
    readTime: 5,
    likes: 234,
    excerpt: "In the remote villages of Kenya, a quiet revolution is taking place. Communities are banding together to install solar grids that not only provide clean energy but also create local jobs and economic opportunities."
  },
  {
    id: "2",
    title: "Urban Farming Feeds Manhattan",
    content: "Vertical farms in New York City are producing fresh vegetables year-round while using 95% less water than traditional farming.",
    country: "United States",
    category: "Urban Agriculture",
    imageUrl: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MDAiIGhlaWdodD0iMjAwIiB2aWV3Qm94PSIwIDAgNDAwIDIwMCI+PHJlY3Qgd2lkdGg9IjQwMCIgaGVpZ2h0PSIyMDAiIGZpbGw9IiM0Q0FGNTAIIC8+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTAwLDIwKSI+PHJlY3QgeD0iMjAiIHk9IjIwIiB3aWR0aD0iMTYwIiBoZWlnaHQ9IjEyMCIgZmlsbD0iI0UwRTBFMCIgc3Ryb2tlPSIjNjY2IiBzdHJva2Utd2lkdGg9IjIiLz48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzMCwzMCkiPjxwYXRoIGQ9Ik0wIDAgTDEwIDEwIEwwIDIwIEwtMTAgMTAgWiIgZmlsbD0iIzIyOEIyMiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjAsMTApIi8+PHBhdGggZD0iTTAgMCBMMTAgMTAgTDAgMjAgTC0xMCAxMCBaIiBmaWxsPSIjMjI4QjIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg0MCwxMCkiLz48cGF0aCBkPSJNMCAwIEwxMCAxMCBMMCAyMCBMLTEwIDEwIFoiIGZpbGw9IiMyMjhCMjIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDYwLDEwKSIvPjxwYXRoIGQ9Ik0wIDAgTDEwIDEwIEwwIDIwIEwtMTAgMTAgWiIgZmlsbD0iIzIyOEIyMiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoODAsMTApIi8+PC9nPjwvZz48dGV4dCB4PSIyMCIgeT0iMTgwIiBmaWxsPSJ3aGl0ZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE0Ij5VcmJhbiBGYXJtaW5nIE5ZQzwvdGV4dD48L3N2Zz4=",
    readTime: 7,
    likes: 189,
    excerpt: "In the heart of Manhattan, towering vertical farms are revolutionizing how we think about food production in urban environments."
  },
  {
    id: "3",
    title: "Ocean Cleanup Success in Philippines",
    content: "Local fishermen partner with scientists to remove plastic waste from Manila Bay using innovative floating barriers.",
    country: "Philippines",
    category: "Ocean Conservation",
    imageUrl: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MDAiIGhlaWdodD0iMjAwIiB2aWV3Qm94PSIwIDAgNDAwIDIwMCI+PHJlY3Qgd2lkdGg9IjQwMCIgaGVpZ2h0PSIyMDAiIGZpbGw9IiM0NjgyQjQiLz48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MCw1MCkiPjxlbGxpcHNlIGN4PSIxNTAiIGN5PSI1MCIgcng9IjEyMCIgcnk9IjMwIiBmaWxsPSIjODdDRUVCIi8+PHBhdGggZD0iTTEwMCA1MCBMMJAWCA1MCBMMTkwIDcwIEwxMTAgNzAgWiIgZmlsbD0iIzIyOEIyMiIvPjxjaXJjbGUgY3g9IjgwIiBjeT0iNjAiIHI9IjUiIGZpbGw9IiNGRjQ1MDAiLz48Y2lyY2xlIGN4PSIyMjAiIGN5PSI0MCIgcj0iNCIgZmlsbD0iI0ZGNDUwMCIvPjxjaXJjbGUgY3g9IjE2MCIgY3k9IjMwIiByPSIzIiBmaWxsPSIjRkY0NTAwIi8+PC9nPjx0ZXh0IHg9IjIwIiB5PSIxODAiIGZpbGw9IndoaXRlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTQiPk9jZWFuIENsZWFudXAgUGhpbGlwcGluZXM8L3RleHQ+PC9zdmc+",
    readTime: 6,
    likes: 312,
    excerpt: "Manila Bay's transformation from a polluted waterway to a thriving marine ecosystem showcases the power of community-driven conservation efforts."
  },
  {
    id: "4",
    title: "Green Roofs Transform Copenhagen",
    content: "Denmark's capital mandates green roofs on all new buildings, creating urban biodiversity corridors and reducing flood risk.",
    country: "Denmark",
    category: "Urban Planning",
    imageUrl: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MDAiIGhlaWdodD0iMjAwIiB2aWV3Qm94PSIwIDAgNDAwIDIwMCI+PHJlY3Qgd2lkdGg9IjQwMCIgaGVpZ2h0PSIyMDAiIGZpbGw9IiM4N0NFRUIiLz48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MCw4MCkiPjxyZWN0IHg9IjIwIiB5PSI0MCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSIjRDJCNDhDIi8+PHBhdGggZD0iTTIwIDQwIEw1MCAyMCBMODAgNDAgWiIgZmlsbD0iIzIyOEIyMiIvPjxyZWN0IHg9IjEwMCIgeT0iNTAiIHdpZHRoPSI1MCIgaGVpZ2h0PSI1MCIgZmlsbD0iI0QyQjQ4QyIvPjxwYXRoIGQ9Ik0xMDAgNTAgTDEyNSAzMCBMMTUwIDUwIFoiIGZpbGw9IiMzMkNEMzIiLz48cmVjdCB4PSIxODAiIHk9IjQ1IiB3aWR0aD0iNzAiIGhlaWdodD0iNTUiIGZpbGw9IiNEMkI0OEMiLz48cGF0aCBkPSJNMTgwIDQ1IEwyMTUgMjUgTDI1MCA0NSBaIiBmaWxsPSIjMjI4QjIyIi8+PC9nPjx0ZXh0IHg9IjIwIiB5PSIxODAiIGZpbGw9IndoaXRlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTQiPkdyZWVuIFJvb2ZzIENvcGVuaGFnZW48L3RleHQ+PC9zdmc+",
    readTime: 4,
    likes: 156,
    excerpt: "Copenhagen's innovative green roof policy is creating a network of urban habitats while addressing climate adaptation challenges."
  },
  {
    id: "5",
    title: "Indigenous Forest Guardians of Brazil",
    content: "Traditional knowledge meets modern technology as indigenous communities use drones to protect the Amazon rainforest.",
    country: "Brazil",
    category: "Forest Conservation",
    imageUrl: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MDAiIGhlaWdodD0iMjAwIiB2aWV3Qm94PSIwIDAgNDAwIDIwMCI+PHJlY3Qgd2lkdGg9IjQwMCIgaGVpZ2h0PSIyMDAiIGZpbGw9IiMwMDY0MDAiLz48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSg1MCw1MCkiPjxjaXJjbGUgY3g9IjUwIiBjeT0iNTAiIHI9IjE1IiBmaWxsPSIjMjI4QjIyIi8+PGNpcmNsZSBjeD0iMTAwIiBjeT0iMzAiIHI9IjIwIiBmaWxsPSIjMzJDRDMyIi8+PGNpcmNsZSBjeD0iMTUwIiBjeT0iNjAiIHI9IjE4IiBmaWxsPSIjMjI4QjIyIi8+PGNpcmNsZSBjeD0iMjAwIiBjeT0iNDAiIHI9IjE2IiBmaWxsPSIjMzJDRDMyIi8+PGNpcmNsZSBjeD0iMjUwIiBjeT0iNzAiIHI9IjEyIiBmaWxsPSIjMjI4QjIyIi8+PHJlY3QgeD0iMTcwIiB5PSIxMCIgd2lkdGg9IjIwIiBoZWlnaHQ9IjQiIGZpbGw9IiM4MDgwODAiLz48Y2lyY2xlIGN4PSIxODAiIGN5PSI4IiByPSIzIiBmaWxsPSIjRkYwMDAwIi8+PC9nPjx0ZXh0IHg9IjIwIiB5PSIxODAiIGZpbGw9IndoaXRlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTQiPkFtYXpvbiBGb3Jlc3QgUHJvdGVjdGlvbjwvdGV4dD48L3N2Zz4=",
    readTime: 8,
    likes: 445,
    excerpt: "In the Amazon, indigenous communities are using cutting-edge technology to preserve their ancestral lands and the world's lungs."
  },
  {
    id: "6",
    title: "Wind Power Lifts Rural Scotland",
    content: "Community-owned wind farms provide clean energy and economic revitalization to Scotland's remote Highland communities.",
    country: "Scotland",
    category: "Wind Energy",
    imageUrl: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MDAiIGhlaWdodD0iMjAwIiB2aWV3Qm94PSIwIDAgNDAwIDIwMCI+PHJlY3Qgd2lkdGg9IjQwMCIgaGVpZ2h0PSIyMDAiIGZpbGw9IiM4N0NFRUIiLz48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDAsNTApIj48bGluZSB4MT0iNTAiIHkxPSIxMDAiIHgyPSI1MCIgeTI9IjIwIiBzdHJva2U9IiNFMEUwRTAiIHN0cm9rZS13aWR0aD0iMyIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDUwLDIwKSByb3RhdGUoNDUpIj48cGF0aCBkPSJNMCAwIEwtMzAgLTUgTC0yNSAtNDAgWiIgZmlsbD0id2hpdGUiLz48cGF0aCBkPSJNMCAwIEwzMCAtNSBMMjUgLTQwIFoiIGZpbGw9IndoaXRlIi8+PHBhdGggZD0iTTAgMCBMNSAzMCBMNDAgMjUgWiIgZmlsbD0id2hpdGUiLz48L2c+PGxpbmUgeDE9IjE1MCIgeTE9IjEwMCIgeDI9IjE1MCIgeTI9IjI1IiBzdHJva2U9IiNFMEUwRTAiIHN0cm9rZS13aWR0aD0iMyIvPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDE1MCwyNSkgcm90YXRlKDkwKSI+PHBhdGggZD0iTTAgMCBMLTMwIC01IEwtMjUgLTQwIFoiIGZpbGw9IndoaXRlIi8+PHBhdGggZD0iTTAgMCBMMzAgLTUgTDI1IC00MCBaIiBmaWxsPSJ3aGl0ZSIvPjxwYXRoIGQ9Ik0wIDAgTDUgMzAgTDQwIDI1IFoiIGZpbGw9IndoaXRlIi8+PC9nPjwvZz48dGV4dCB4PSIyMCIgeT0iMTgwIiBmaWxsPSJ3aGl0ZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE0Ij5XaW5kIFBvd2VyIFNjb3RsYW5kPC90ZXh0Pjwvc3ZnPg==",
    readTime: 5,
    likes: 198,
    excerpt: "Scottish Highlands communities are harnessing their abundant wind resources to create sustainable energy and economic independence."
  }
];

const categories = Array.from(new Set(mockStories.map(story => story.category)));
const countries = Array.from(new Set(mockStories.map(story => story.country)));

export default function Stories() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedCountry, setSelectedCountry] = useState("all");
  const [selectedStory, setSelectedStory] = useState<typeof mockStories[0] | null>(null);

  const filteredStories = mockStories.filter(story => {
    const matchesSearch = story.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         story.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || story.category === selectedCategory;
    const matchesCountry = selectedCountry === "all" || story.country === selectedCountry;
    return matchesSearch && matchesCategory && matchesCountry;
  });

  if (selectedStory) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 p-8">
        <div className="max-w-4xl mx-auto">
          <Button 
            variant="outline" 
            onClick={() => setSelectedStory(null)} 
            className="mb-6"
          >
            ← Back to Stories
          </Button>
          
          <Card>
            <CardHeader>
              <div className="flex flex-wrap gap-2 mb-4">
                <Badge variant="secondary">{selectedStory.category}</Badge>
                <Badge variant="outline">
                  <MapPin className="mr-1 h-3 w-3" />
                  {selectedStory.country}
                </Badge>
                <Badge variant="outline">
                  <Clock className="mr-1 h-3 w-3" />
                  {selectedStory.readTime} min read
                </Badge>
              </div>
              <CardTitle className="text-3xl">{selectedStory.title}</CardTitle>
              <CardDescription className="text-lg mt-4">
                {selectedStory.excerpt}
              </CardDescription>
            </CardHeader>
            <CardContent className="prose dark:prose-invert max-w-none">
              <div className="h-64 mb-6 overflow-hidden rounded-lg">
                <img 
                  src={selectedStory.imageUrl} 
                  alt={selectedStory.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-lg leading-relaxed">
                {selectedStory.content}
              </p>
              <p className="mt-6">
                This story highlights the incredible work being done by communities around the world to address environmental challenges. 
                From grassroots initiatives to innovative technologies, these efforts demonstrate that positive change is possible when 
                people come together with a shared vision for a sustainable future.
              </p>
              <p>
                The success of this initiative provides a model that other communities can adapt and implement in their own contexts. 
                By sharing these stories, we hope to inspire and connect environmental champions worldwide.
              </p>
              
              <div className="flex items-center gap-4 mt-8 pt-6 border-t">
                <Button variant="outline" size="sm">
                  <Heart className="mr-2 h-4 w-4" />
                  {selectedStory.likes} likes
                </Button>
                <Button variant="outline" size="sm">
                  Share Story
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 flex items-center justify-center gap-3">
            <BookOpen className="h-10 w-10 text-purple-600" />
            Environmental Stories
          </h1>
          <p className="text-xl text-muted-foreground">
            Inspiring stories of environmental action from around the globe
          </p>
        </div>

        {/* Search and Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search stories..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger>
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedCountry} onValueChange={setSelectedCountry}>
            <SelectTrigger>
              <SelectValue placeholder="All Countries" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Countries</SelectItem>
              {countries.map(country => (
                <SelectItem key={country} value={country}>{country}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="text-center flex items-center justify-center text-sm text-muted-foreground">
            {filteredStories.length} stories found
          </div>
        </div>

        {/* Stories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStories.map((story) => (
            <Card 
              key={story.id} 
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setSelectedStory(story)}
            >
              <CardHeader>
                <div className="h-48 mb-4 overflow-hidden rounded-lg">
                  <img 
                    src={story.imageUrl} 
                    alt={story.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex flex-wrap gap-2 mb-2">
                  <Badge variant="secondary">{story.category}</Badge>
                  <Badge variant="outline">
                    <MapPin className="mr-1 h-3 w-3" />
                    {story.country}
                  </Badge>
                </div>
                <CardTitle className="line-clamp-2">{story.title}</CardTitle>
                <CardDescription className="line-clamp-3">
                  {story.excerpt}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {story.readTime} min read
                  </div>
                  <div className="flex items-center gap-1">
                    <Heart className="h-4 w-4" />
                    {story.likes}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredStories.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-lg font-medium mb-2">No stories found</h3>
            <p className="text-muted-foreground">Try adjusting your search criteria</p>
          </div>
        )}
      </div>
    </div>
  );
}